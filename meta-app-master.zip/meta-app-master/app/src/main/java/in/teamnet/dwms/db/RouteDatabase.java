package in.teamnet.dwms.db;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import in.teamnet.dwms.db.dao.PoiPointDao;
import in.teamnet.dwms.db.dao.RoutePointDao;
import in.teamnet.dwms.db.models.DateConverter;
import in.teamnet.dwms.db.models.PoiPoint;
import in.teamnet.dwms.db.models.RoutePoint;

/**
 * <h1>Room DB provider for the route_db</h1>
 * <p>
 * Copyright 2021 Vivekanand Mishra.
 * All rights reserved.
 *
 * @author Vivekanand Mishra
 * @version 1.0
 */
@Database(entities = {RoutePoint.class, PoiPoint.class}, exportSchema = false, version = 2)
@TypeConverters({DateConverter.class})
public abstract class RouteDatabase extends RoomDatabase {
    public abstract RoutePointDao routePointDao();
    public abstract PoiPointDao poiPointDao();

    private static final String DB_NAME = "route_db";
    private static volatile RouteDatabase instance = null;

    public static RouteDatabase getInstance(@NonNull final Context context) {
        if (instance == null) {
            synchronized (RouteDatabase.class) {
                if (instance == null)
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                            RouteDatabase.class,
                            DB_NAME)
                            .fallbackToDestructiveMigration()
                            .build();
            }
        }
        return instance;
    }
}
