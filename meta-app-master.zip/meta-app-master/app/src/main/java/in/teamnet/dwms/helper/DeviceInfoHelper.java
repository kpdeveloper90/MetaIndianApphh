package in.teamnet.dwms.helper;

import android.os.Build;

import in.teamnet.dwms.BuildConfig;

/**
 * <h1>Helper class to get device info</h1>
 * <p>
 * Copyright 2021 Vivekanand Mishra.
 * All rights reserved.
 *
 * @author Vivekanand Mishra
 * @version 1.0
 */
public class DeviceInfoHelper {


}
