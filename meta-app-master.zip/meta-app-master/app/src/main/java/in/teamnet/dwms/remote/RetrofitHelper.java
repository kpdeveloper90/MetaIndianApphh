package in.teamnet.dwms.remote;

import androidx.annotation.NonNull;
import androidx.core.util.Pair;

import in.teamnet.dwms.R;
import in.teamnet.dwms.db.models.PoiPoint;
import in.teamnet.dwms.helper.ConnactionCheckApplication;
import in.teamnet.dwms.helper.preference.EncryptedPreferenceHelper;
import in.teamnet.dwms.pojo.model.User;
import in.teamnet.dwms.pojo.payload.RoutePayload;
import in.teamnet.dwms.pojo.response.BackendResponse;
import in.teamnet.dwms.pojo.response.LiveVehicleResponse;
import in.teamnet.dwms.pojo.response.MetadataUserResponse;
import in.teamnet.dwms.pojo.response.PoiCreateResponse;
import in.teamnet.dwms.pojo.response.PoiResponse;
import in.teamnet.dwms.pojo.response.RouteListResponse;
import in.teamnet.dwms.pojo.response.RoutePayloadResponse;
import in.teamnet.dwms.pojo.response.RouteResponse;
import in.teamnet.dwms.pojo.response.WardResponse;
import in.teamnet.dwms.pojo.response.ZoneResponse;
import retrofit2.Call;
import retrofit2.Retrofit;

/**
 * <h1>Class to get api instance fo the server for this app using retrofit</h1>
 * <p>
 * Copyright 2021 Vivekanand Mishra.
 * All rights reserved.
 *
 * @author Vivekanand Mishra
 * @version 1.0
 */
public class RetrofitHelper {
    private static final String BASE_URL = "https://dev.ecosense-enviro.com/";

    public Retrofit getClient() {
        return new RetrofitClient().getClient(BASE_URL);
    }

    public static RetrofitApiInterface create() {
        return new RetrofitClient().getClient(BASE_URL).create(RetrofitApiInterface.class);
    }

    public static Call<MetadataUserResponse> authenticateMetadataUser(@NonNull User user) {
        return create().authenticateMetadataUser(user, getToken());
    }

    public static Call<RoutePayloadResponse> sendRoutePoints(@NonNull RoutePayload routePayload) {
        return create().sendRoutePoints(routePayload, getToken());
    }

    public static Call<ZoneResponse> getZoneList() {
        return create().getZones(getToken(), 1);
    }

    public static Call<WardResponse> getWardList() {
        return create().getWards(getToken(), 1);
    }

    public static Call<ZoneResponse> getZoneList(final int page) {
        return create().getZones(getToken(), page);
    }

    public static Call<WardResponse> getWardList(final int page) {
        return create().getWards(getToken(), page);
    }

    public static Call<LiveVehicleResponse> getLiveVehicleList() {
        return create().getLiveVehicles(getToken());
    }

    public static Call<RouteListResponse> getRouteList() {
        return create().getRoutes(getToken());
    }

    public static Call<RouteResponse> getRoute(final String routeId) {
        return create().getRoute(getToken(), routeId);
    }

    public static Call<PoiResponse> getPoiList(final String routeId) {
        return create().getPois(getToken(), routeId);
    }

    public static Call<PoiCreateResponse> createPoi(@NonNull final PoiPoint poiPoint) {
        return create().createPoi(getToken(), poiPoint);
    }

    public static Call<BackendResponse> updatePoi(@NonNull final String poiId, @NonNull final PoiPoint poiPoint) {
        return create().updatePoi(getToken(), poiId, poiPoint);
    }

    public static Call<BackendResponse> deletePoi(@NonNull final String poiId) {
        return create().deletePoi(getToken(), poiId);
    }

    private static String getToken() {
        return "Bearer " + new EncryptedPreferenceHelper(ConnactionCheckApplication.getInstance()).getMetaUserToken();
    }

    public static Pair<String, String> getProblemSolutionPair(@NonNull BackendError backendError) {
        Pair<String, String> problemSolutionPair;

        switch (backendError) {
            case UNSUCCESSFUL:
                problemSolutionPair = new Pair<>(ConnactionCheckApplication.getInstance().getString(R.string.dialog_problem_server_down),
                        ConnactionCheckApplication.getInstance().getString(R.string.dialog_solution_server_down));
                break;
            case PARSING:
                problemSolutionPair = new Pair<>(ConnactionCheckApplication.getInstance().getString(R.string.dialog_problem_parsing_error),
                        ConnactionCheckApplication.getInstance().getString(R.string.dialog_solution_parsing_error));
                break;
            case NETWORK:
                problemSolutionPair = new Pair<>(ConnactionCheckApplication.getInstance().getString(R.string.dialog_problem_network_failure),
                        ConnactionCheckApplication.getInstance().getString(R.string.dialog_solution_network_failure));
                break;
            default:
                problemSolutionPair = new Pair<>(ConnactionCheckApplication.getInstance().getString(R.string.dialog_problem_invalid_request),
                        ConnactionCheckApplication.getInstance().getString(R.string.dialog_solution_invalid_request));
        }

        return problemSolutionPair;
    }
}
